"""M16：Knowledge Rule Explorer / Review Queue API 测试。"""

from __future__ import annotations

from fastapi.testclient import TestClient

from apps.api.main import app

client = TestClient(app)


def test_knowledge_stats():
    r = client.get("/api/v1/knowledge/stats")
    assert r.status_code == 200
    d = r.json()
    assert d["executableTotal"] == 223
    assert d["executableByDomain"] == {"event": 21, "temporal": 20, "tiaohou": 182}


def test_knowledge_rules_with_conflict_neighbors():
    r = client.get("/api/v1/knowledge/rules")
    assert r.status_code == 200
    d = r.json()
    by_id = {x["id"]: x for x in d["rules"]}
    assert len(d["rules"]) == 223
    car3 = by_id["EV-CAR-03"]
    assert any(c["edgeType"] == "rescues" for c in car3["conflictNeighbors"])
    guan = by_id["TR-SP-02"]
    assert guan["domain"] == "temporal"


def test_knowledge_graph_and_rescues():
    g = client.get("/api/v1/knowledge/graph").json()
    assert g["nodeCount"] == 229 and g["edgeCount"] == 18
    r = client.get("/api/v1/knowledge/rescues").json()
    assert r["count"] == 6


def test_knowledge_review_queue_readonly():
    r = client.get("/api/v1/knowledge/review-queue")
    assert r.status_code == 200
    d = r.json()
    assert d["count"] > 0
    assert all(i["priority"] in ("P1", "P2", "P3") for i in d["items"])
    assert all(i.get("reviewNote") is None for i in d["items"])  # 不伪造人工审核
    # 排序：P1 在前
    priorities = [i["priority"] for i in d["items"]]
    assert priorities == sorted(priorities, key=lambda p: {"P1": 0, "P2": 1, "P3": 2}[p])


def test_dashboard_endpoints():
    """M19 Dashboard 数据端点：funnel/coverage-audit/rule-audit/release。"""
    fn = client.get("/api/v1/knowledge/funnel").json()
    assert fn["funnel"]["executable"] == 223
    assert fn["funnel"]["sources"] == 8 and fn["funnel"]["candidates"] == 556
    cov = client.get("/api/v1/knowledge/coverage-audit").json()
    assert cov["ruleCount"] == 223
    ra = client.get("/api/v1/knowledge/rule-audit").json()
    assert ra["ruleCount"] == 21  # rule-audit 只审计 event 域规则
    rel = client.get("/api/v1/knowledge/release").json()
    assert rel["metadata"]["counts"]["executableRules"] == 223
    # qualitySummary 可能 stale（门内测试运行时刻），只验结构；freshness 归 release_check
    assert "allPass" in rel["qualitySummary"]


def test_evaluation_compare_endpoint():
    r = client.get("/api/v1/knowledge/evaluation-compare")
    assert r.status_code == 200
    d = r.json()
    assert d["entryCount"] >= 1
    assert all("regressionAgainstPrevious" in c for c in d["comparisons"])


def test_graph_data_shape_for_svg():
    """SVG 画布数据契约：节点含 id/label（或 domain），边含 between/type。"""
    g = client.get("/api/v1/knowledge/graph").json()
    for n in g["nodes"]:
        assert "id" in n
        assert "type" in n and n["type"] in ("rule", "predicate")
    for e in g["edges"]:
        assert e["type"] in ("conflict", "rescues", "school-conflict")
        if e["type"] == "rescues":
            assert e.get("from") and e.get("to")
        else:
            assert len(e.get("between", [])) == 2
